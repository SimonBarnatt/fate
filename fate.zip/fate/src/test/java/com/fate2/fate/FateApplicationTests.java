package com.fate2.fate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FateApplicationTests {

	@Test
	void contextLoads() {
	}

}
